package cts.Baciu.Robert.g1093.pattern.Factory;

public class Junior extends BankAccount {

	
    public Junior(double Balance, String Id,double interest) {
        balance = Balance;
        id = Id;
        
        
    
}
   
}
