package cts.Baciu.Robert.g1093.pattern.Command;

public class BankTransactions extends BankModule {

	@Override
	public void processTransaction(String sourseAccount, String destinationAccount, double value,
			String destinationBank) {
	     
		
		
	}

}
