package cts.Baciu.Robert.g1093.pattern.Factory;

public class Credit extends BankAccount {

	
	 public Credit(double Balance, String Id,int noInstalments,double creditLimit) {
	       super(Balance,Id);
	    }
	    
}
