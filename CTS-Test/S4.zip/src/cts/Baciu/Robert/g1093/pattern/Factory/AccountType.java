package cts.Baciu.Robert.g1093.pattern.Factory;

public enum AccountType {
  CREDIT,DEBIT,JUNIOR
}
